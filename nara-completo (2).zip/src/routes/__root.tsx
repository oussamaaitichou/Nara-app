import { createRootRoute, HeadContent, Outlet, Scripts, useRouterState } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { AppShell } from "@/components/layout/app-shell";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import appCss from "../styles.css?url";

const APP_NAME = "Nara";

/** Pantallas que se muestran dentro del menú lateral desplegable (/panel ya lo trae puesto). */
const CON_MENU = ["/consulta", "/erp", "/admin", "/valorar"];

function Contenido() {
  const pathname = useRouterState({ select: (st) => st.location.pathname });
  const conMenu = CON_MENU.some((p) => pathname === p || pathname.startsWith(`${p}/`));
  if (!conMenu) return <Outlet />;
  return (
    <AppShell fullBleed={pathname.startsWith("/consulta")}>
      <Outlet />
    </AppShell>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: `${APP_NAME} — Asesora de farmacia` },
      {
        name: "description",
        content:
          "Nara es la asesora con IA para la oficina de farmacia. Recetas, sustitución, inspección, guardias y mostrador, en lenguaje claro.",
      },
      { name: "theme-color", content: "#14214f" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/icon-180.png" },
    ],
  }),
  component: RootComponent,
});

function RootComponent() {
  return (
    <html lang="es" className="antialiased" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <PreviewHostBridge />
        <AuthProvider>
          <Contenido />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  );
}
