import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft } from "lucide-react";
import { NaraMark } from "@/components/brand/logo";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/login")({
  component: LoginPage,
  head: () => ({
    meta: [
      { title: "Acceder — Nara" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
});

const campo =
  "h-11 w-full rounded-lg border border-line bg-surface px-3 text-sm text-ink outline-none focus:border-teal focus:ring-2 focus:ring-teal/20";

async function enviarJson(url: string, body: unknown): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const json = (await res.json().catch(() => ({}))) as { error?: string };
    return res.ok ? { ok: true } : { ok: false, error: json.error ?? "No se ha podido entrar." };
  } catch {
    return { ok: false, error: "Error de red. Inténtalo de nuevo." };
  }
}

function LoginPage() {
  const navigate = useNavigate();
  const [modo, setModo] = useState<"cuenta" | "codigo">("cuenta");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [codigo, setCodigo] = useState("");
  const [mensaje, setMensaje] = useState<string | null>(null);
  const [enviando, setEnviando] = useState(false);

  // Si el acceso no está activado o ya has entrado, pasa directo al panel.
  useEffect(() => {
    let vivo = true;
    fetch("/api/acceso")
      .then((r) => r.json() as Promise<{ accesoActivo?: boolean; autenticado?: boolean }>)
      .then((j) => { if (vivo && (!j.accesoActivo || j.autenticado)) void navigate({ to: "/panel" }); })
      .catch(() => undefined);
    return () => { vivo = false; };
  }, [navigate]);

  async function enviar(e: React.FormEvent) {
    e.preventDefault();
    setEnviando(true);
    setMensaje(null);
    const r =
      modo === "cuenta"
        ? await enviarJson("/api/registro", { accion: "login", email, password })
        : await enviarJson("/api/acceso", { codigo });
    if (!r.ok) {
      setMensaje(r.error ?? "No se ha podido entrar.");
      setEnviando(false);
      return;
    }
    void navigate({ to: "/panel" });
  }

  return (
    <div className="flex min-h-dvh items-center justify-center bg-gradient-to-br from-[#dfe6ff] via-bg to-[#f1ecff] px-4 py-10">
      <div className="w-full max-w-sm space-y-4">
        <Link to="/" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted hover:text-ink">
          <ArrowLeft className="size-4" /> Volver al inicio
        </Link>
        <form
          className="space-y-4 rounded-2xl border border-line bg-surface p-6 shadow-[var(--shadow-lift)]"
          onSubmit={(e) => void enviar(e)}
        >
          <NaraMark className="size-11" />
          <div>
            <h1 className="font-display text-2xl font-bold text-ink">Acceder a Nara</h1>
            <p className="mt-1 text-sm text-muted">Entra con tu cuenta aprobada o con un código de prueba.</p>
          </div>

          <div className="grid grid-cols-2 gap-1 rounded-lg bg-bg p-1" role="tablist">
            {([["cuenta", "Mi cuenta"], ["codigo", "Código de prueba"]] as const).map(([k, t]) => (
              <button
                key={k}
                type="button"
                role="tab"
                aria-selected={modo === k}
                onClick={() => { setModo(k); setMensaje(null); }}
                className={`rounded-md px-3 py-1.5 text-sm font-medium ${modo === k ? "bg-surface text-teal shadow-sm" : "text-muted hover:text-ink"}`}
              >
                {t}
              </button>
            ))}
          </div>

          {modo === "cuenta" ? (
            <>
              <label className="block space-y-1 text-sm text-ink-soft">
                <span>Correo</span>
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className={campo} autoComplete="email" />
              </label>
              <label className="block space-y-1 text-sm text-ink-soft">
                <span>Contraseña</span>
                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required className={campo} autoComplete="current-password" />
              </label>
            </>
          ) : (
            <label className="block space-y-1 text-sm text-ink-soft">
              <span>Código</span>
              <input type="text" value={codigo} onChange={(e) => setCodigo(e.target.value)} required className={campo} autoComplete="off" />
            </label>
          )}

          {mensaje ? <p className="text-sm text-danger">{mensaje}</p> : null}
          <Button type="submit" className="w-full" disabled={enviando}>
            {enviando ? "Entrando…" : "Entrar"}
          </Button>
          <p className="text-xs text-muted">
            ¿No tienes cuenta? Necesitas una <span className="text-ink">invitación del administrador</span>.
          </p>
        </form>
      </div>
    </div>
  );
}
