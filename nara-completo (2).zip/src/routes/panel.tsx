import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  ArrowRight, BarChart3, ChevronRight, ClipboardCheck, FileText, KeyRound, MessageSquare,
  Repeat, Send, Settings, ShieldCheck, Sparkles, Star, Stethoscope,
} from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { NaraMark } from "@/components/brand/logo";

export const Route = createFileRoute("/panel")({
  component: PanelPage,
  head: () => ({ meta: [{ title: "Nara — Panel" }] }),
});

type Tono = "indigo" | "violeta" | "ambar" | "verde";
const TONOS: Record<Tono, string> = {
  indigo: "bg-[#e5eaff] text-[#3f55d6]",
  violeta: "bg-[#efe8ff] text-[#7a52e0]",
  ambar: "bg-[#fff1d6] text-[#b7791f]",
  verde: "bg-[#dcf5e9] text-[#1f9d6b]",
};

const ACCESOS: { to: string; icon: typeof MessageSquare; titulo: string; texto: string; tono: Tono }[] = [
  { to: "/consulta", icon: MessageSquare, titulo: "Consultar a Nara", texto: "Recetas, sustitución, inspección y mostrador.", tono: "indigo" },
  { to: "/erp", icon: BarChart3, titulo: "Gestión y datos", texto: "Ventas, compras, equipo y clientes.", tono: "violeta" },
  { to: "/valorar", icon: Star, titulo: "Valorar farmacia", texto: "Informe para comprar o vender.", tono: "ambar" },
  { to: "/admin", icon: Settings, titulo: "Administración", texto: "Invitaciones, códigos y usuarios.", tono: "verde" },
];

const PREGUNTAS = ["¿Qué debe llevar una receta médica?", "Sustitución de medicamentos", "Preparar una inspección"];

const TEMAS: { q: string; icon: typeof FileText; titulo: string; texto: string }[] = [
  { q: "¿Cómo dispenso una receta privada?", icon: FileText, titulo: "Recetas y dispensación", texto: "Qué pedir, qué anotar y cuándo no dispensar." },
  { q: "¿Cuándo puedo sustituir un medicamento?", icon: Repeat, titulo: "Sustitución y genéricos", texto: "Reglas claras para sustituir con seguridad." },
  { q: "¿Qué suele revisar una inspección de farmacia?", icon: ClipboardCheck, titulo: "Inspección", texto: "Lista de puntos para llegar tranquilo." },
  { q: "¿Qué debo preguntar antes de dispensar un medicamento?", icon: Stethoscope, titulo: "Seguridad del paciente", texto: "Preguntas clave en el mostrador." },
];

function PanelPage() {
  const navigate = useNavigate();
  const [listo, setListo] = useState(false);
  useEffect(() => {
    let vivo = true;
    fetch("/api/acceso")
      .then(async (r) => ({ ok: r.ok, j: (await r.json()) as { accesoActivo?: boolean; autenticado?: boolean } }))
      .then(({ ok, j }) => {
        if (!vivo) return;
        if (!ok || (j.accesoActivo && !j.autenticado)) void navigate({ to: "/login" });
        else setListo(true);
      })
      .catch(() => { if (vivo) void navigate({ to: "/login" }); });
    return () => { vivo = false; };
  }, [navigate]);
  if (!listo) return <div className="min-h-dvh bg-bg" aria-busy="true" />;
  return (
    <AppShell title="Panel" subtitle="Todo Nara en un solo sitio">
      <div className="mx-auto max-w-6xl space-y-5">
        {/* Bienvenida */}
        <section className="relative overflow-hidden rounded-3xl border border-line bg-gradient-to-br from-[#dfe6ff] via-[#eaefff] to-[#f5f1ff] p-6 shadow-[var(--shadow-soft)] sm:p-9">
          <div className="relative z-10 max-w-xl">
            <h1 className="font-display text-3xl font-bold tracking-tight text-nav sm:text-4xl">Bienvenido a Nara</h1>
            <p className="mt-2 text-base font-medium text-ink-soft sm:text-lg">Tu asesoría con IA para farmacias, siempre contigo.</p>
            <p className="mt-2 text-sm text-muted">Resuelve dudas del mostrador, ordena la gestión y valora farmacias con criterio profesional.</p>
            <Link
              to="/consulta"
              className="mt-5 inline-flex h-11 items-center gap-2 rounded-full bg-gradient-to-r from-[#3f55d6] to-[#5b6ef0] px-5 text-sm font-semibold text-white shadow-lg shadow-[#3f55d6]/30 transition hover:brightness-110"
            >
              <Sparkles className="size-4" /> Consultar a Nara <ArrowRight className="size-4" />
            </Link>
          </div>
          <div aria-hidden className="pointer-events-none absolute -right-6 top-1/2 hidden -translate-y-1/2 sm:block">
            <div className="relative">
              <div className="size-56 rounded-full bg-gradient-to-br from-[#c9d4ff] to-[#e6dcff] blur-[2px]" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="flex size-28 items-center justify-center rounded-3xl bg-white shadow-xl shadow-[#3f55d6]/20">
                  <NaraMark className="size-16" />
                </div>
              </div>
              <span className="absolute -left-24 top-4 rounded-2xl bg-white px-3 py-2 text-xs font-semibold text-nav shadow-lg">
                Tu aliada en <span className="text-teal">gestión farmacéutica</span>
              </span>
            </div>
          </div>
        </section>

        {/* Accesos */}
        <section aria-label="Accesos" className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {ACCESOS.map((a) => {
            const Icon = a.icon;
            return (
              <Link
                key={a.to}
                to={a.to}
                className="group flex flex-col gap-3 rounded-2xl border border-line bg-surface p-4 shadow-[var(--shadow-soft)] transition hover:-translate-y-0.5 hover:border-teal/40 hover:shadow-[var(--shadow-lift)]"
              >
                <span className={`inline-flex size-11 items-center justify-center rounded-xl ${TONOS[a.tono]}`}>
                  <Icon className="size-5" />
                </span>
                <div>
                  <p className="font-display text-base font-bold text-ink">{a.titulo}</p>
                  <p className="mt-0.5 text-xs leading-relaxed text-muted sm:text-sm">{a.texto}</p>
                </div>
              </Link>
            );
          })}
        </section>

        <div className="grid gap-5 lg:grid-cols-[1.25fr_1fr]">
          {/* Asesor */}
          <section className="rounded-2xl border border-line bg-surface p-5 shadow-[var(--shadow-soft)]">
            <div className="flex items-center gap-2">
              <h2 className="font-display text-base font-bold text-ink">Tu asesora Nara</h2>
              <span className="inline-flex items-center gap-1 text-xs font-medium text-[#1f9d6b]">
                <span className="size-1.5 rounded-full bg-[#1f9d6b]" /> En línea
              </span>
            </div>
            <div className="mt-4 flex items-start gap-3">
              <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-teal-soft">
                <NaraMark className="size-7" />
              </span>
              <div className="rounded-2xl rounded-tl-sm bg-bg px-4 py-3 text-sm text-ink-soft">
                <p className="font-semibold text-ink">¡Hola! 👋 ¿En qué puedo ayudarte hoy?</p>
                <p className="mt-1.5 leading-relaxed">Puedo orientarte con recetas, sustitución, inspección y dudas del mostrador, en lenguaje claro.</p>
              </div>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              {PREGUNTAS.map((q) => (
                <Link
                  key={q}
                  to="/consulta"
                  search={{ q }}
                  className="rounded-full border border-teal/30 bg-surface px-3.5 py-1.5 text-xs font-medium text-teal transition hover:bg-teal-mist sm:text-sm"
                >
                  {q}
                </Link>
              ))}
            </div>
            <Link
              to="/consulta"
              className="mt-4 flex h-12 items-center gap-3 rounded-full border border-line bg-surface px-4 text-sm text-subtle transition hover:border-teal/40"
            >
              <span className="flex-1">Escribe tu consulta…</span>
              <span className="flex size-9 items-center justify-center rounded-full bg-gradient-to-br from-[#3f55d6] to-[#7a52e0] text-white">
                <Send className="size-4" />
              </span>
            </Link>
          </section>

          {/* Temas frecuentes */}
          <section className="rounded-2xl border border-line bg-surface shadow-[var(--shadow-soft)]">
            <div className="flex items-center justify-between px-5 pt-5">
              <h2 className="font-display text-base font-bold text-ink">Temas frecuentes</h2>
              <Link to="/consulta" className="text-xs font-semibold text-teal hover:underline">Ver todos</Link>
            </div>
            <ul className="mt-3 divide-y divide-line">
              {TEMAS.map((t) => {
                const Icon = t.icon;
                return (
                  <li key={t.titulo}>
                    <Link to="/consulta" search={{ q: t.q }} className="flex items-center gap-3 px-5 py-3.5 transition hover:bg-bg">
                      <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-teal-soft text-teal">
                        <Icon className="size-4" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block text-sm font-semibold text-ink">{t.titulo}</span>
                        <span className="block truncate text-xs text-muted">{t.texto}</span>
                      </span>
                      <ChevronRight className="size-4 shrink-0 text-subtle" />
                    </Link>
                  </li>
                );
              })}
            </ul>
          </section>
        </div>

        {/* Banner valoración */}
        <section className="flex flex-col gap-4 overflow-hidden rounded-2xl bg-gradient-to-r from-nav via-[#1d2f78] to-[#3f55d6] p-6 text-white shadow-[var(--shadow-lift)] sm:flex-row sm:items-center sm:justify-between sm:p-7">
          <div className="max-w-xl">
            <h2 className="font-display text-xl font-bold">¿Vas a comprar o vender una farmacia?</h2>
            <p className="mt-1 text-sm text-white/75">Pide tu informe de valoración y llega a la negociación con números claros.</p>
          </div>
          <Link to="/valorar" className="inline-flex h-11 shrink-0 items-center gap-2 rounded-full bg-white px-5 text-sm font-semibold text-nav transition hover:bg-white/90">
            Valorar farmacia <ArrowRight className="size-4" />
          </Link>
        </section>

        <nav aria-label="Más" className="flex flex-wrap items-center gap-x-5 gap-y-2 pb-2 text-sm text-muted">
          <Link to="/login" className="inline-flex items-center gap-1.5 hover:text-ink"><KeyRound className="size-4" /> Acceso</Link>
          <a href="/legal/privacidad" className="inline-flex items-center gap-1.5 hover:text-ink"><ShieldCheck className="size-4" /> Legal y privacidad</a>
        </nav>
      </div>
    </AppShell>
  );
}
